// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initNavigation();
    initScrollAnimations();
    initProductInteractions();
    initFormHandling();
    initMobileMenu();
    initSmoothScrolling();
    initCartFunctionality();
    initCSVUpload();
});

// Navigation functionality
function initNavigation() {
    const header = document.querySelector('.header');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Sticky header on scroll
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            header.style.background = 'rgba(10, 10, 10, 0.98)';
            header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.3)';
        } else {
            header.style.background = 'rgba(10, 10, 10, 0.95)';
            header.style.boxShadow = 'none';
        }
    });
    
    // Active navigation link highlighting
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Mobile menu functionality
function initMobileMenu() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close menu when clicking on a link
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }
}

// Smooth scrolling for all anchor links
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Scroll animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.category-card, .product-card, .testimonial-card, .trending-item');
    animatedElements.forEach(el => {
        observer.observe(el);
    });
    
    // Hero section animation
    const heroTitle = document.querySelector('.hero-title');
    const heroSubtitle = document.querySelector('.hero-subtitle');
    const heroButtons = document.querySelector('.hero-buttons');
    
    if (heroTitle) {
        setTimeout(() => heroTitle.style.opacity = '1', 100);
    }
    if (heroSubtitle) {
        setTimeout(() => heroSubtitle.style.opacity = '1', 300);
    }
    if (heroButtons) {
        setTimeout(() => heroButtons.style.opacity = '1', 500);
    }
}

// Product interactions
function initProductInteractions() {
    const productCards = document.querySelectorAll('.product-card');
    const categoryCards = document.querySelectorAll('.category-card');
    
    // Product card hover effects
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Category card hover effects
    categoryCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const img = this.querySelector('img');
            if (img) {
                img.style.transform = 'scale(1.1)';
            }
        });
        
        card.addEventListener('mouseleave', function() {
            const img = this.querySelector('img');
            if (img) {
                img.style.transform = 'scale(1)';
            }
        });
    });
    
    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll('.btn-add-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productCard = this.closest('.product-card');
            const productName = productCard.querySelector('.product-name').textContent;
            
            // Add to cart animation
            this.style.background = '#4CAF50';
            this.textContent = 'Added!';
            
            setTimeout(() => {
                this.style.background = 'linear-gradient(45deg, #d4af37, #f4d03f)';
                this.textContent = 'Add to Cart';
            }, 2000);
            
            // Update cart count
            updateCartCount();
            
            // Show notification
            showNotification(`${productName} added to cart!`);
        });
    });
}

// Cart functionality
function initCartFunctionality() {
    const cartBtn = document.querySelector('.cart-btn');
    const cartCount = document.querySelector('.cart-count');
    
    if (cartBtn) {
        cartBtn.addEventListener('click', function() {
            // Cart functionality would be implemented here
            showNotification('Cart functionality coming soon!');
        });
    }
}

// Update cart count
function updateCartCount() {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        let currentCount = parseInt(cartCount.textContent) || 0;
        cartCount.textContent = currentCount + 1;
        cartCount.style.animation = 'pulse 0.5s ease';
        
        setTimeout(() => {
            cartCount.style.animation = '';
        }, 500);
    }
}

// Form handling
function initFormHandling() {
    const contactForm = document.querySelector('.contact-form form');
    const newsletterForm = document.querySelector('.newsletter-form');
    
    // Contact form
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const name = this.querySelector('input[type="text"]').value;
            const email = this.querySelector('input[type="email"]').value;
            const message = this.querySelector('textarea').value;
            
            if (name && email && message) {
                showNotification('Thank you for your message! We\'ll get back to you soon.');
                this.reset();
            } else {
                showNotification('Please fill in all fields.');
            }
        });
    }
    
    // Newsletter form
    if (newsletterForm) {
        const newsletterBtn = newsletterForm.querySelector('.btn');
        const newsletterInput = newsletterForm.querySelector('input[type="email"]');
        
        if (newsletterBtn) {
            newsletterBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const email = newsletterInput.value;
                
                if (email && isValidEmail(email)) {
                    showNotification('Thank you for subscribing to our newsletter!');
                    newsletterInput.value = '';
                } else {
                    showNotification('Please enter a valid email address.');
                }
            });
        }
    }
}

// Email validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Notification system
function showNotification(message) {
    // Remove existing notification
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: linear-gradient(45deg, #d4af37, #f4d03f);
        color: #000;
        padding: 1rem 2rem;
        border-radius: 10px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        transform: translateX(400px);
        transition: transform 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// Trending slider functionality
function initTrendingSlider() {
    const slider = document.querySelector('.trending-slider');
    if (!slider) return;
    
    let isDown = false;
    let startX;
    let scrollLeft;
    
    slider.addEventListener('mousedown', (e) => {
        isDown = true;
        slider.classList.add('active');
        startX = e.pageX - slider.offsetLeft;
        scrollLeft = slider.scrollLeft;
    });
    
    slider.addEventListener('mouseleave', () => {
        isDown = false;
        slider.classList.remove('active');
    });
    
    slider.addEventListener('mouseup', () => {
        isDown = false;
        slider.classList.remove('active');
    });
    
    slider.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - slider.offsetLeft;
        const walk = (x - startX) * 2;
        slider.scrollLeft = scrollLeft - walk;
    });
}

// Parallax effect for hero section
function initParallaxEffect() {
    const hero = document.querySelector('.hero');
    if (!hero) return;
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const rate = scrolled * -0.5;
        hero.style.transform = `translateY(${rate}px)`;
    });
}

// Initialize trending slider and parallax
document.addEventListener('DOMContentLoaded', function() {
    initTrendingSlider();
    initParallaxEffect();
});

// CSV Upload and Product Processing
function initCSVUpload() {
    const csvFileInput = document.getElementById('csvFileInput');
    const csvUploadArea = document.getElementById('csvUploadArea');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const productsContainer = document.getElementById('productsContainer');
    
    // File input change handler
    if (csvFileInput) {
        csvFileInput.addEventListener('change', handleFileUpload);
    }
    
    // Drag and drop handlers
    if (csvUploadArea) {
        csvUploadArea.addEventListener('dragover', handleDragOver);
        csvUploadArea.addEventListener('dragleave', handleDragLeave);
        csvUploadArea.addEventListener('drop', handleDrop);
        csvUploadArea.addEventListener('click', () => csvFileInput.click());
    }
}

function handleDragOver(e) {
    e.preventDefault();
    e.currentTarget.classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type === 'text/csv') {
        processCSVFile(files[0]);
    } else {
        showNotification('Please upload a valid CSV file.');
    }
}

function handleFileUpload(e) {
    const file = e.target.files[0];
    if (file && file.type === 'text/csv') {
        processCSVFile(file);
    } else {
        showNotification('Please select a valid CSV file.');
    }
}

function processCSVFile(file) {
    const loadingIndicator = document.getElementById('loadingIndicator');
    const productsContainer = document.getElementById('productsContainer');
    
    // Show loading indicator
    loadingIndicator.style.display = 'block';
    productsContainer.innerHTML = '';
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const csvContent = e.target.result;
        const productLinks = parseCSV(csvContent);
        
        if (productLinks.length === 0) {
            showNotification('No product links found in CSV file.');
            loadingIndicator.style.display = 'none';
            return;
        }
        
        // Process each product link
        processProductLinks(productLinks);
    };
    
    reader.readAsText(file);
}

function parseCSV(csvContent) {
    const lines = csvContent.split('\n');
    const productLinks = [];
    
    for (let i = 1; i < lines.length; i++) { // Skip header row
        const line = lines[i].trim();
        if (line && line.startsWith('http')) {
            productLinks.push(line);
        }
    }
    
    return productLinks;
}

function extractProductInfoFromURL(url) {
    try {
        // Extract product name from URL
        const urlParts = url.split('/');
        const productName = decodeURIComponent(urlParts[urlParts.length - 2]);
        
        // Determine category and create appropriate data
        let category = 'General';
        let basePrice = 2000; // Base price in PKR
        let sizes = ['S', 'M', 'L', 'XL'];
        let description = '';
        let imageUrl = '';
        
        if (productName.toLowerCase().includes('jacket')) {
            category = 'Jackets';
            basePrice = 3500;
            sizes = ['S', 'M', 'L', 'XL', 'XXL'];
            description = 'Premium quality jacket with modern design and comfortable fit.';
            imageUrl = 'https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
        } else if (productName.toLowerCase().includes('t-shirt') || productName.toLowerCase().includes('shirt')) {
            category = 'Shirts';
            basePrice = 1500;
            sizes = ['S', 'M', 'L', 'XL', 'XXL'];
            description = 'Comfortable and stylish shirt perfect for everyday wear.';
            imageUrl = 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
        } else if (productName.toLowerCase().includes('track') || productName.toLowerCase().includes('suit')) {
            category = 'Tracksuits';
            basePrice = 4000;
            sizes = ['S', 'M', 'L', 'XL', 'XXL'];
            description = 'Modern tracksuit set with premium materials and contemporary style.';
            imageUrl = 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
        } else if (productName.toLowerCase().includes('boot') || productName.toLowerCase().includes('sneaker')) {
            category = 'Shoes';
            basePrice = 3000;
            sizes = ['8', '9', '10', '11', '12'];
            description = 'High-quality footwear with superior comfort and durability.';
            imageUrl = 'https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
        } else {
            category = 'Fashion';
            basePrice = 2500;
            description = 'Premium quality fashion item with excellent craftsmanship.';
            imageUrl = 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80';
        }
        
        // Add random variation to price
        const priceVariation = Math.floor(Math.random() * 1000) - 500;
        const originalPrice = basePrice + priceVariation;
        const finalPrice = originalPrice + 1000; // Add 1000 PKR profit
        
        return {
            title: productName,
            image: imageUrl,
            description: description,
            price: finalPrice,
            originalPrice: originalPrice,
            sizes: sizes,
            category: category,
            url: url
        };
    } catch (error) {
        console.error('Error extracting product info:', error);
        return null;
    }
}

async function processProductLinks(productLinks) {
    const productsContainer = document.getElementById('productsContainer');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const processedProducts = [];
    
    console.log('Processing product links:', productLinks);
    
    // Process each product link
    for (const url of productLinks) {
        try {
            console.log('Processing URL:', url);
            const productInfo = extractProductInfoFromURL(url);
            
            if (productInfo) {
                processedProducts.push(productInfo);
                console.log('Extracted product:', productInfo.title);
            } else {
                console.log('Failed to extract product info from:', url);
            }
        } catch (error) {
            console.error('Error processing URL:', url, error);
        }
    }
    
    // Simulate processing delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Hide loading indicator
    loadingIndicator.style.display = 'none';
    
    if (processedProducts.length > 0) {
        // Render products
        renderProducts(processedProducts);
        showNotification(`Successfully processed ${processedProducts.length} products from Markaz!`);
    } else {
        // Show fallback message
        productsContainer.innerHTML = `
            <div class="no-products-message">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>No Products Found</h3>
                <p>Unable to process the product links. Please check your CSV file format.</p>
            </div>
        `;
        showNotification('No products could be processed from the CSV file.');
    }
}

function renderProducts(products) {
    const productsContainer = document.getElementById('productsContainer');
    
    productsContainer.innerHTML = products.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.title}">
                <div class="product-badge">New</div>
            </div>
            <div class="product-info">
                <div class="product-category">${product.category}</div>
                <h3 class="product-name">${product.title}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-sizes">
                    <span class="sizes-label">Sizes: </span>
                    <span class="sizes">${product.sizes.join(', ')}</span>
                </div>
                <div class="product-rating">
                    <span class="stars">★★★★★</span>
                    <span class="rating-count">(${Math.floor(Math.random() * 50) + 10})</span>
                </div>
                <div class="price-container">
                    <p class="product-price">₨ ${product.price.toLocaleString()}</p>
                    <p class="original-price">₨ ${product.originalPrice.toLocaleString()}</p>
                </div>
                <button class="btn btn-add-cart">Add to Cart</button>
            </div>
        </div>
    `).join('');
    
    // Re-initialize product interactions for new cards
    initProductInteractions();
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }
    
    .trending-slider {
        cursor: grab;
    }
    
    .trending-slider.active {
        cursor: grabbing;
    }
    
    .fade-in {
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.6s ease;
    }
    
    .fade-in.visible {
        opacity: 1;
        transform: translateY(0);
    }
    
    .product-sizes {
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
    }
    
    .sizes-label {
        color: #888;
    }
    
    .sizes {
        color: #d4af37;
        font-weight: 500;
    }
    
    .price-container {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .original-price {
        color: #888;
        text-decoration: line-through;
        font-size: 0.9rem;
    }
`;
document.head.appendChild(style);
